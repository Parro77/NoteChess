colName = [" ", "a", "b", "c", "d", "e", "f", "h"]
rowName = [1,2,3,4,5,6,7,8]
pieceLetter = ["N", "Q", "B", "R", "K"]
pieceName = ["Knight", "Queen", "Bishop", "Rook", "Knight", "Pawn"]
whiteMove = []
blackMove = []
player = "white"
col = " "
row = " "
piece = " "
def readMove():
  def split(word): 
    return [char for char in word]  
  move = input("Your Move?")
  if player == "white":
    whiteMove.append(move)
  if player == "black":
    blackMove.append(move)
  move = split(move)
  if move.count("x") == 1:
    if len(move) == 3:
      piece = pieceName[5]
      col = move[1]
      col = colName.index(col)
      row = int(move[2])
    if len(move) == 4:
      piece = move[0]
      piece = pieceLetter.index(piece)
      piece = pieceName[piece]
      col = move[2]
      col = colName.index(col)
      row = int(move[3])
    if len(move) == 5:
      piece = move[0]
      piece = pieceLetter.index(piece)
      piece = pieceName[piece]
      col = move[3]
      col = colName.index(col)
      row = int(move[4])
      if colName.count(move[1]):
        startCol = move[1]
        startCol = colName.index(startCol)
        print("piece file # %d" % startCol)
      else: 
        if rowName.count(int(move[1])):
          startRow = move[1]
          startRow = int(move[1])
          print("piece rank #: %d" % startRow)  
    if len(move) == 6:
      piece = move[0]
      piece = pieceLetter.index(piece)
      piece = pieceName[piece]
      col = move[4]
      col = colName.index(col)
      row = int(move[5])
      startRow = move[2]
      startCol = move[1]
  else:
    if len(move) == 2:
      piece = pieceName[5]
      col = move[0]
      col = colName.index(col)
      row = int(move[1])
    if len(move) == 3:
      piece = move[0]
      piece = pieceLetter.index(piece)
      piece = pieceName[piece]
      col = move[1]
      col = colName.index(col)
      row = int(move[2])
    if len(move) == 4:
      piece = move[0]
      piece = pieceLetter.index(piece)
      piece = pieceName[piece]
      col = move[2]
      col = colName.index(col)
      row = int(move[3])
      if colName.count(move[1]):
        startCol = move[1]
        startCol = colName.index(startCol)
        print("piece file # %d" % startCol)
      else: 
        if rowName.count(int(move[1])):
          startRow = move[1]
          startRow = int(move[1])
          print("piece rank #: %d" % startRow)
    if len(move) == 5:
      piece = move[0]
      piece = pieceLetter.index(piece)
      piece = pieceName[piece]
      col = move[3]
      col = colName.index(col)
      row = int(move[4])
      startRow = move[2]
      startCol = move[1]

readMove()